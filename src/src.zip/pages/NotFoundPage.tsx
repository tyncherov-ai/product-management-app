const NotFoundPage = () => {
  return <div>NotFoundPage</div>;
};

export default NotFoundPage;
