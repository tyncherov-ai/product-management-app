import React, { useState } from "react";
import { type Product } from "../../types";
import { useProducts } from "../../hooks/useProducts";
import { DeleteIcon, EditIcon, ViewIcon } from "../icons/Icons";
import { StatusBadge, CategoryBadge } from "../ui/Badge";
import { formatPrice, formatDate } from "../../utils/formatters";
import { ConfirmDialog } from "../ui/ConfirmDialog";
import Pagination from "./Pagination";
import type { ProductsTableProps } from "../../types/common";

const ProductsTable: React.FC<ProductsTableProps> = ({
  products,
  onEdit,
  currentPage,
  totalItems,
  itemsPerPage,
  onPageChange,
}) => {
  const { deleteProduct } = useProducts();
  const [deleteConfirm, setDeleteConfirm] = useState<{
    id: string;
    name: string;
  } | null>(null);

  const handleDelete = (id: string, name: string) => {
    setDeleteConfirm({ id, name });
  };

  const confirmDelete = async () => {
    if (deleteConfirm) {
      try {
        await deleteProduct(deleteConfirm.id);
        setDeleteConfirm(null);
      } catch (error) {
        console.error("Failed to delete product:", error);
      }
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-6">
        <h2 className="text-xl font-semibold text-gray-800">
          Product Inventory
        </h2>
        <p className="text-gray-600 mt-1">
          Manage your products with full CRUD operations
        </p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Product
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Price
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Category
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Stock
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Created
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {products.map((product) => (
              <tr key={product.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="font-semibold text-gray-900">
                    {product.name}
                  </div>
                  <div className="text-sm text-gray-500">ID: {product.id}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap font-semibold text-gray-800">
                  {formatPrice(product.data?.price)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <CategoryBadge category={product.data?.category} />
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-gray-700">
                  {product.data?.stock ?? "N/A"}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <StatusBadge stock={product.data?.stock} />
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-gray-700">
                  {formatDate(product.createdAt)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    <button className="p-2 rounded-full text-blue-600 bg-blue-100 hover:bg-blue-200">
                      <ViewIcon />
                    </button>
                    <button
                      onClick={() => onEdit(product)}
                      className="p-2 rounded-full text-yellow-600 bg-yellow-100 hover:bg-yellow-200"
                    >
                      <EditIcon />
                    </button>
                    <button
                      onClick={() => handleDelete(product.id, product.name)}
                      className="p-2 rounded-full text-red-600 bg-red-100 hover:bg-red-200"
                    >
                      <DeleteIcon />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Pagination
        currentPage={currentPage}
        totalItems={totalItems}
        itemsPerPage={itemsPerPage}
        onPageChange={onPageChange}
      />

      <ConfirmDialog
        open={!!deleteConfirm}
        onClose={() => setDeleteConfirm(null)}
        onConfirm={confirmDelete}
        title="Delete Product"
        message={`Are you sure you want to delete "${deleteConfirm?.name}"?`}
      />
    </div>
  );
};

export default ProductsTable;
