export interface LoginFormData {
  email: string;
  password: string;
}

export interface RegisterFormData {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
}

export interface ProductFormData {
  name: string;
  price: number;
  category: string;
  stock: number;
}
