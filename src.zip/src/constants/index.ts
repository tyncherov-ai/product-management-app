export const ITEMS_PER_PAGE = 5;

export const VALIDATION_RULES = {
  email: {
    required: "Email is required",
    pattern: {
      value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
      message: "Invalid email format",
    },
  },
  password: {
    required: "Password is required",
    minLength: {
      value: 6,
      message: "Password must be at least 6 characters",
    },
  },
  name: {
    required: "Name is required",
  },
  productName: {
    required: "Product name is required",
  },
  category: {
    required: "Category is required",
  },
  price: {
    required: "Price is required",
    valueAsNumber: true,
    min: { value: 0, message: "Price cannot be negative" },
  },
  stock: {
    required: "Stock is required",
    valueAsNumber: true,
    min: { value: 0, message: "Stock cannot be negative" },
  },
} as const;
