import { useState, useMemo } from "react";
import type { Product } from "../types";

export const useFilters = (items: Product[]) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  const filteredItems = useMemo(() => {
    let filtered = [...items];

    if (searchQuery) {
      filtered = filtered.filter((item) =>
        item.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (selectedCategory !== "All") {
      filtered = filtered.filter(
        (item) => item.data?.category === selectedCategory
      );
    }

    return filtered;
  }, [items, searchQuery, selectedCategory]);

  const categories = useMemo(() => {
    const unique = new Set(
      items
        .map((p) => p.data?.category)
        .filter((c): c is string => typeof c === "string" && c.length > 0)
    );
    return ["All", ...Array.from(unique)];
  }, [items]);

  return {
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    filteredItems,
    categories,
  };
};
