import { useCallback } from "react";
import { useAppDispatch, useAppSelector } from "./redux";
import { fetchProducts, deleteProduct } from "../store/slices/productsSlice";

export const useProducts = () => {
  const dispatch = useAppDispatch();
  const { items, loadingList, error } = useAppSelector((s) => s.products);

  const fetchProductsList = useCallback(() => {
    dispatch(fetchProducts());
  }, [dispatch]);

  const deleteProductById = useCallback(
    (id: string) => {
      return dispatch(deleteProduct(id)).unwrap();
    },
    [dispatch]
  );

  return {
    products: items,
    loading: loadingList,
    error,
    fetchProducts: fetchProductsList,
    deleteProduct: deleteProductById,
  };
};
